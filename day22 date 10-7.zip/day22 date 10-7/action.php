<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "form db";
$conn =  mysqli_connect($servername, $username, $password, $dbname);
$first_name = $last_name = $email = $pno = $gender = $country = "";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          $first_name = test_input($_POST["f_name"]);
          $last_name = test_input($_POST["l_name"]);
          $email = test_input($_POST["email"]);
          $pno = test_input($_POST["pno"]);
          $gender = test_input($_POST["gender"]);
          $country = test_input($_POST["select"]);
        }
         function test_input($data) {
             $data = trim($data);
             $data = stripslashes($data);
             $data = htmlspecialchars($data);
             return $data;
           }
          $sql = "INSERT INTO form (first_name,last_name, email,pno,gender,country) VALUES ('$first_name','$last_name','$email','$pno','$gender','$country')";
          if ($conn->query($sql) === TRUE) {
              echo "Record inserted successfully.";
          } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
          }
          echo $first_name;
?>