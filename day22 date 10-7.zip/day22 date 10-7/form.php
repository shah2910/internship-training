<html>
    <head>
        <title>form using php.</title>
        <head>
            <style>
            body{
                text-align: center;
                align:center;
            }
            fieldset{
                position: absolute;
                top:20%;
                left:35%;
                border:2px solid black;
            }
            </style>
        </head>
    </head>
    <body style="background-color:pink;">
    
        <fieldset>
           <legend>&hearts;<b> ENTER YOUR DETAILS: </b>&hearts;</legend>
    <form method="POST" action="action.php">
         <p><label><h4>YOUR FIRST NAME:</label><input type="text" name="first_name"/></h4></p>
         <p><label><h4>YOUR LAST NAME:</label><input type="text" name="last_name"/></h4></p>
        <p><h4><label>E-mail;:</label><input type="text" name="email"/></h4></p>
        <p><h4><label>MOBILE NO:</label><input type="number" name="pno"/></p>
        <p><h4>enter your gender:</h4></p>
           <label>Male<input type="radio" 
                 name="gender" value="male" /></label>
           <label>Female<input type="radio"
                 name="gender" value="female" /></label>
        <p><h4>SELECT YOUR COUNTRY:</h4></p>
        <p><select name="select">
            <option value="INDIA">INDIA</option>
            <option value="US">US</option>
            <option value="SOUTH AFRICA">SOUTH AFRICA</option>
            <option value="SOUTH KORIA">SOUTH KORIA</option>
            <option value="OTHERS">OTHERS</option>
        </select></p>
        <button type="submit">SUBMIT</button>
    </fieldset>
    </form>
        </body>
</html>