<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ass3db";
$conn =  mysqli_connect($servername, $username, $password, $dbname);
$fname = $lname = $email = $phone = $remember = $suggestion = "";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          $fname = test_input($_POST["fname"]);
          $lname = test_input($_POST["lname"]);
          $email = test_input($_POST["email"]);
          $phone = test_input($_POST["phone"]);
          $remember = test_input($_POST["remember"]);
          $suggestion = test_input($_POST["suggestion"]);
        }
        function test_input($data) {
              $data = trim($data);
              $data = stripslashes($data);
              $data = htmlspecialchars($data);
             return $data;
          }
          $sql = "INSERT INTO form1 (fname,lname, email,phone,remember,suggestion) VALUES ('$fname','$lname','$email','$phone','$remember','$suggestion')";
          if ($conn->query($sql) === TRUE) {
              echo "Record inserted successfully.";
          } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
          }
?>