<html>
<head>
  <title>FEEDBACK FORM </title>
  <style>
          body {font-family: Arial;
                background-image: linear-gradient(135deg, #FFF6B7 10%, #F6416C 100%);
                }
          /* The Modal */
          .modal {
            display: none; 
            padding-top: 90px; 
            left: 0;
            top: 0;
            width: 100%; 
            height: 100%; 
            overflow: auto; 
          }
          /* Modal for content */
          .modal-content {
            background-image: linear-gradient(135deg, #43CBFF 10%, #9708CC 100%);
            opacity : 0.9;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 60%;
            box-shadow: 10px rgba(25, 25, 25, 0.7);
          }
          /* Close Button */
          .close {
            color: #aaaaaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
          }
          .close:hover,
          .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
          }
          button{
                  background-color: rgb(232, 171, 149);
                  border-radius: 20px;
          }
          button:hover{
                  background-color: rgb(198, 92, 145);
          }
  </style>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <center>
      <h2>FeedBack Form</h2>
      <button id="myBtn">Open FeedBack Form</button>
      <!-- Modal -->
      <div id="myModal" class="modal">
      <!-- Modal content -->
      <div class="modal-content">
        <center>
          <span class="close">&times;</span>
            <p><b>Add Your FeedBack...</b></p>
              <form method="POST" action="assignme2.php">
                <label for="fname"><b>First name:</b></label>
                  <input type="text" autofocus placeholder="enter your first name:" maxlength="100" 
                  name="fname" required/><br/><br/>
                <label for="lname"><b>Last name:</b></label>
                  <input type="text" autofocus placeholder="enter your last name:" 
                  maxlength="100" name="lname" required/><br/><br/>
                <label for="email"><b>Email:</b></label>&nbsp;&nbsp;
                  <input type="email" id="email" placeholder="Enter Your E-mail" name="email"
                   required><br/><br/>
                <label><b>Phone :</b> </label>&nbsp;
                <input type="tel" id="phone" name="phone" placeholder="Enter your Phone number:" 
                maxlength="10" required>  <br/>
                <label><input type="checkbox" name="remember"> Remember me</label><br/>
                <p><b>What Do You Think about quality of our Website.</b></p>
                      <img id="myImage1" onclick="changeImage1()" src="smi1.0.png" width="100" height="100"
                        data-toggle="tooltip" data-placement="right" title="BEST!...">
                      <img id="myImage2" onclick="changeImage2()" src="smi2.0.png" width="100" height="100"
                        data-toggle="tooltip" data-placement="right" title="GOOD!...">
                      <img id="myImage3" onclick="changeImage3()" src="smi3.0.png" width="100" height="100" 
                      data-toggle="tooltip" data-placement="right" title="OKAYSHHH!...">
                      <img id="myImage4" onclick="changeImage4()" src="smi4.0.png" width="100" height="100" data-toggle="tooltip" data-placement="right" title="NOT YOUR BEST!..."><br/>
              .  <p><b>Do you have any suggestion for us?</b> </p>
                <textarea name=" suggestion" rows="5" cols="40" placeholder="Enter Your Suggestion.."></textarea><br/><br/>
                          <button onclick="myf()" type="submit">SUBMIT</button> 
              </form>
        </center>
        </div>
      </div>
      <script>
          function myf()
          {
            alert("thank you for your feedback.....")
          }
          function changeImage1() {
            let image1 = document.getElementById('myImage1');
            let image2 = document.getElementById('myImage2');
            let image3 = document.getElementById('myImage3');
            let image4 = document.getElementById('myImage4');
            
            image1.src = "smi1.1.png";
            image2.src = "smi2.0.png";
            image3.src = "smi3.0.png";
            image4.src = "smi4.0.png";
            /*if (image.src.match("bulbon")) {
              image.src = "smi1.0.png";
            } else {
              image.src = "smi1.1.png";
            }*/
          }
          function changeImage2() {
            let image1 = document.getElementById('myImage1');
            let image2 = document.getElementById('myImage2');
            let image3 = document.getElementById('myImage3');
            let image4 = document.getElementById('myImage4');
            
            image1.src = "smi1.0.png";
            image2.src = "smi2.1.png";
            image3.src = "smi3.0.png";
            image4.src = "smi4.0.png";
          }
          function changeImage3() {
            let image1 = document.getElementById('myImage1');
            let image2 = document.getElementById('myImage2');
            let image3 = document.getElementById('myImage3');
            let image4 = document.getElementById('myImage4');
            
            image1.src = "smi1.0.png";
            image2.src = "smi2.0.png";
            image3.src = "smi3.1.png";
            image4.src = "smi4.0.png";
          }
          function changeImage4() {
            let image1 = document.getElementById('myImage1');
            let image2 = document.getElementById('myImage2');
            let image3 = document.getElementById('myImage3');
            let image4 = document.getElementById('myImage4');
            
            image1.src = "smi1.0.png";
            image2.src = "smi2.0.png";
            image3.src = "smi3.0.png";
            image4.src = "4.1.png";
          }
          // Getting modal
          var modal = document.getElementById("myModal");
          //use for open the modal
          var btn = document.getElementById("myBtn");
          // Get the span to closes the modal
          var span = document.getElementsByClassName("close")[0];
          // When the user clicks the button, open the modal 
          btn.onclick = function() {
              modal.style.display = "block";
          }
          // When the user clicks on <span>, close the modal
          span.onclick = function() {
              modal.style.display = "none";
          }
     </script>
  </center>
</body>
</html>